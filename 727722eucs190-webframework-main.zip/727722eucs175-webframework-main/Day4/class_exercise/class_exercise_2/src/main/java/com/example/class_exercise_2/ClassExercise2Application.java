package com.example.class_exercise_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassExercise2Application {

	public static void main(String[] args) {
		SpringApplication.run(ClassExercise2Application.class, args);
	}

}
