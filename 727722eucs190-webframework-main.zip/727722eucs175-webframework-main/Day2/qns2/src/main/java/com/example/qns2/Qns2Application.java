package com.example.qns2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qns2Application {

	public static void main(String[] args) {
		SpringApplication.run(Qns2Application.class, args);
	}

}
