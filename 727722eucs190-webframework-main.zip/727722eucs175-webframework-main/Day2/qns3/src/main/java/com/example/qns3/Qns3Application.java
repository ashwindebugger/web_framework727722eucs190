package com.example.qns3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qns3Application {

	public static void main(String[] args) {
		SpringApplication.run(Qns3Application.class, args);
	}

}
