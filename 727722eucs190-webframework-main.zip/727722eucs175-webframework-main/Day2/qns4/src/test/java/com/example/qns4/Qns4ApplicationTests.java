package com.example.qns4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Qns4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
