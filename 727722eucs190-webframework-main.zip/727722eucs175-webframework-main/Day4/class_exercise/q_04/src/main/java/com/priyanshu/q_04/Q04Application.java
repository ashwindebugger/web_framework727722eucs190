package com.priyanshu.q_04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Q04Application {

	public static void main(String[] args) {
		SpringApplication.run(Q04Application.class, args);
	}

}
