package com.example.qns4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qns4Application {

	public static void main(String[] args) {
		SpringApplication.run(Qns4Application.class, args);
	}

}
