package com.example.qns1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qns1Application {

	public static void main(String[] args) {
		SpringApplication.run(Qns1Application.class, args);
	}

}
